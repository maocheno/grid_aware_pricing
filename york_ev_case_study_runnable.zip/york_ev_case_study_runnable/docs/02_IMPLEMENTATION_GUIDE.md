# 程序实现指南

## 1. 推荐模块

```text
src/
|-- config.py                 # YAML、随机种子和路径
|-- data_loader.py            # CSV schema、索引和缓存
|-- road_network.py           # BPR、counter mapping、最短路
|-- demand.py                 # episode demand 与车辆能量
|-- choice_model.py           # hub/outside multinomial logit
|-- queue_model.py            # service slots、等待与排队能量
|-- energy_dispatch.py        # PV、battery、grid、SOC、unmet energy
|-- preference_inference.py   # lower-layer outside-cost update
|-- env.py                    # 8-agent six-step environment
|-- mappo.py                  # actors、central critic、PPO update
|-- baselines.py              # fixed、myopic、independent、no-inference
|-- evaluate.py               # deterministic evaluation 与统计
`-- logging_schema.py         # 统一逐时/逐站结果字段
```

当前 package 已提供 `scripts/queue_state.py` 作为新版排队状态转移的可复用参考实现。完整 MAPPO 环境仍应按上述模块逐步实现。

## 2. 总体数据流

```mermaid
flowchart LR
    A["Road graph + ATC flow"] --> B["BPR edge times"]
    B --> C["OD-to-hub route times"]
    D["OD potential demand"] --> E["Generalized costs"]
    C --> E
    F["Hub prices + previous wait"] --> E
    G["Estimated outside cost"] --> H["Multinomial logit"]
    E --> H
    H --> I["New hub arrivals Q(t)"]
    J["Previous wait + queued energy"] --> K["Queue admission"]
    I --> K
    K --> L["Admitted energy"]
    M["PV + SOC + grid price/limit"] --> N["Energy dispatch"]
    L --> N
    N --> O["Profit + feasibility penalties"]
    K --> P["Next wait + queued energy"]
    I --> Q["Lower-layer preference update"]
    Q --> G
    O --> R["Shared MAPPO reward"]
```

## 3. 初始化与 reset

### 程序初始化一次

1. 读取 YAML，并相对 YAML 所在目录解析六个 CSV。
2. 对所有 CSV 执行 schema、单位、主键和时间范围检查。
3. 建立有向 `networkx.DiGraph`，预计算每条边的 `T0_e` 和 `C_e`。
4. 建立 counter-edge mapping，并按小时缓存 `x_e(t)`。
5. 按 `(timestamp, od_id)` 和 `(timestamp, hub_id)` 建立字典索引。
6. 建立 8 个独立 actor 和一个 centralized critic。

### 每个 episode reset

1. 时间设为 16:00。
2. 对每个 hub 设置 `T_i^wait(-1)=0`、`E_i^que(0)=0`。
3. previous price 设为 hub 表中的 0.45 GBP/kWh。
4. SOC 从 16:00 的 `initial_battery_soc_fraction` 读取。
5. 抽取一个 episode demand multiplier。
6. 每个训练 seed 的 outside estimate 从 13.5 GBP 开始；是否跨 episode 保留估计应与实验协议一致。
7. 不要重置网络权重、normalizer 或 preference estimator 的 optimizer state。

## 4. 一个环境时段的顺序

顺序必须固定，避免等待反馈和偏好更新出现 information leakage。

1. **更新交通状态**：由真实 ATC profile 得到 `x_e(t)`，计算 BPR 边时间和 OD-hub route time。
2. **构造 observation**：使用当前可观测状态、previous price、`T_i^wait(t-1)`、`E_i^que(t)` 和当前 outside estimate。
3. **同时选择价格**：8 个 actor 同时输出价格。
4. **生成潜在需求**：读取 `D_k(t)`，训练时加入 episode multiplier 和随机抽样。
5. **计算选择概率**：使用当前价格、当前 route time 和期初预期等待 `T_i^wait(t-1)`。
6. **形成新到达**：得到各 hub 的 `Q_i(t)`、`E_i^req(t)` 和 outside demand。
7. **执行排队准入**：依次计算 `L_i(t)`、`rho_i(t)`、`E_i^pend(t)`、`E_i^adm(t)`。
8. **执行能源调度**：用 PV、battery 和 grid 服务 `E_i^adm(t)`，得到 `E_i^srv(t)`、`U_i(t)`、SOC 和成本。
9. **更新跨时段状态**：计算 `T_i^wait(t)` 和 `E_i^que(t+1)`。
10. **计算利润与 shared reward**。
11. **更新 lower-layer estimate**：只使用本时段可观察的聚合选择结果。
12. **记录 transition 并推进时钟**：下一时段观察 `T_i^wait(t)`、`E_i^que(t+1)`。

## 5. 用户选择层

对 OD group `k` 和 hub `i`：

```text
C_ki = p_i * Ebar_k
       + value_of_time * (route_time_ki / 60 + T_i^wait(t-1))
```

outside option 的 cost 为 `C_out`。选择概率：

```text
P_ki  = exp(-lambda * C_ki) / Z_k
P_out = exp(-lambda * C_out) / Z_k
Z_k   = exp(-lambda * C_out) + sum_i exp(-lambda * C_ki)
```

实现时使用 stable softmax。环境内部用 `true_hidden_cost_gbp=16.5` 生成真实选择；actor 和 critic 只能看到 estimator 当前给出的 `C_hat_out`。

## 6. Lower-layer preference inference

令本时段观察到 outside 数量为 `n_out`，总潜在需求为 `N`，当前模型预测 outside probability 为 `P_hat_out`。聚合 negative log-likelihood 对共享 outside cost 的梯度可写成：

```text
gradient = lambda * (n_out - N * P_hat_out)
C_hat_out <- clip(C_hat_out - eta * gradient, 10, 22)
```

实现建议：

- 对 6 个 OD 的 log-likelihood 求和后更新一次；
- 使用最近 3 个 period 的 rolling loss；
- 按总需求归一化梯度；
- 每个 seed 单独初始化 estimator；
- evaluation 时记录 `C_hat_out`、NLL 和 absolute error。

## 7. Queue 层

基础版本采用论文修订后的 aggregate fluid queue，不做逐车离散事件模拟。服务容量为：

```text
S_i = N_chargers_i * delta_t / service_time_i
```

时段开始时的历史等待状态等价为排队车辆数：

```text
L_i(t) = S_i / delta_t * T_i^wait(t-1)                 # Eq. (13)
```

新到达与历史队列共同决定服务准入比例：

```text
rho_i(t) = min(1, S_i / (L_i(t) + Q_i(t)))             # Eq. (14)
```

当 `L_i(t)+Q_i(t)=0` 时定义 `rho_i(t)=0`。等待时间按新版式 (10) 结转：

```text
T_i^wait(t) = max(
    T_i^wait(t-1) + delta_t * (Q_i(t) / S_i - 1),
    0
)
```

它与剩余车辆表达式完全等价：

```text
T_i^wait(t)
  = delta_t / S_i * max(L_i(t) + Q_i(t) - S_i, 0)
```

所以当本时段到达量低于容量时，旧等待会逐步下降，而不是立即清零；高于容量时则继续累积。

车辆数与能量状态分别计算：

```text
E_i^pend(t)    = E_i^que(t) + E_i^req(t)               # Eq. (15)
E_i^adm(t)     = rho_i(t) * E_i^pend(t)                 # Eq. (16)
E_i^que(t + 1) = (1 - rho_i(t)) * E_i^pend(t)           # Eq. (19)
Q_i^adm(t)     = rho_i(t) * (L_i(t) + Q_i(t))           # Eq. (29)
```

每一步必须验证 `Epend = Eadm + Eque_next`。`queue_capacity_vehicles` 目前仅保留为可选的有限等待空间扩展；论文修订后的 base equations 没有使用该上限，因此主结果中不计算旧版 `overflow`。

## 8. Energy dispatch 层

每个 hub 独立执行确定性 dispatch，输入负荷为 `E_i^adm(t)`，不是新到达的全部请求能量。先满足：

```text
E_i^adm(t) = E_i^srv(t) + U_i(t)                       # Eq. (17)
```

其中 `U_i(t)` 是已经准入但因局部能源不足而未交付的能量。调度顺序：

1. PV 优先直接服务充电负荷。
2. 根据电网价格、battery continuation value 和 degradation cost 决定放电。
3. 再使用 grid import，严格执行功率上限。
4. 剩余 PV 可给电池充电。
5. 严格执行 SOC、battery power、grid import 上限，并禁止同时充放电。

若电池放电为 `d_i`、充电为 `c_i`：

```text
SOC_energy_next = SOC_energy
                  + charge_efficiency * c_i
                  - d_i / discharge_efficiency
```

能源平衡：

```text
served_energy + battery_charge
    = pv_used + grid_import + battery_discharge
admitted_energy = served_energy + unmet_energy
```

实际服务车辆数按式 (30) 计算：

```text
alpha_i(t) = E_i^srv(t) / E_i^adm(t)
Q_i^srv(t) = alpha_i(t) * Q_i^adm(t)
```

当 `E_i^adm(t)=0` 时定义 `alpha_i(t)=0`。用户收入只对 `served_energy` 计算，每一步应 assert 能量平衡误差小于 `1e-6`。

## 9. Profit 与 shared reward

单站利润至少包含：

```text
revenue = retail_price * served_energy
energy_cost = grid_price * grid_import
operating_cost = 1.50 * served_vehicles
battery_cost = 0.03 * battery_throughput
pv_cost = 0.005 * pv_used
profit_i = revenue - energy_cost - operating_cost - battery_cost - pv_cost
```

共享奖励：

```text
reward_raw = sum_i profit_i
             - 120 * sum_i max(T_i^wait(t) - 0.25, 0)
             - 6 * sum_i U_i(t)
reward = 0.01 * reward_raw
```

价格、SOC、battery power、PV balance 和 grid limit 是 hard constraints；等待和 unmet energy 是 soft constraints，并作为独立指标报告。

## 10. MAPPO 接口

### 每个 actor 的 local observation

建议包含以下归一化变量：

- 当前时段编码；
- previous price 和 `T_i^wait(t-1)`；
- `E_i^que(t)`、历史等效排队车辆和 service capacity；
- 本站预测新 arrivals 与请求能量；
- PV available、SOC、battery power headroom；
- grid price、grid import headroom；
- OD 到本站 route time 的加权均值和 p95；
- 当前 `C_hat_out`；
- 上一时段 served energy、unmet energy 和 profit。

不要加入 `true_hidden_cost_gbp`、未来 PV、未来电价或其他 actor 尚未发布的当前动作。

### Centralized critic state

拼接所有 hub local observations，再加：

- 6 个 OD 的当前 potential demand；
- 全系统 public/outside share；
- network-wide PV、grid headroom、总排队能量和总历史等效车辆；
- 当前 joint price vector。

### Beta action

```text
alpha = softplus(raw_alpha) + 1
beta  = softplus(raw_beta) + 1
y ~ Beta(alpha, beta)
price = p_min + y * (p_max - p_min)
```

Evaluation 使用 Beta mean `alpha/(alpha+beta)`。

### Rollout 与更新

- episode horizon 固定为 6；
- 建议累计 20 个完整 episode 后做一次 PPO update；
- 8 agents x 6 steps x 20 episodes = 960 个 agent transitions；
- GAE 不跨 episode 传播；
- shared reward 对所有 actor 相同；
- actor 独立参数，critic 使用 joint state；
- 保存 observation normalizer，并在 evaluation 冻结。

## 11. 推荐实现顺序

1. 输入 loader 和全部 structural assertions。
2. 固定价格、确定性需求的 choice + revised queue 环境。
3. 加入完整 energy dispatch 和 SOC。
4. 复现 package smoke-test 数字。
5. 加入 lower-layer estimator，并测试它从 13.5 向 16.5 收敛。
6. 加入 centralized oracle、fixed tariff 和 no-inference benchmark。
7. 接入 MAPPO，先跑单 seed 100 episode，再跑完整训练。
8. 最后加入随机需求、全部 ablation 和 sensitivity。

## 12. 必须通过的单元测试

- 所有 choice probabilities 非负且和为 1。
- `lambda` 增大时，选择对 cost 差异更敏感。
- BPR 时间不小于自由流时间，并随 `x_e` 单调增加。
- 零 arrivals 且无历史队列时，wait 和 queued energy 均为 0。
- 超容量到达后，下一时段 `T_i^wait` 和 `E_i^que` 均不被清空。
- `T_i^wait` 与 `[L_i+Q_i-S_i]^+` 的车辆 backlog 表达式一致。
- 每一步满足 `Epend = Eadm + Eque_next`。
- 价格始终在 `[0.25, 0.80]`。
- SOC 始终在 `[0.10, 0.95]`。
- 每站每小时能源平衡误差小于 `1e-6`。
- hidden outside cost 不出现在 actor/critic observation。
- 固定价格 deterministic run 复现 README 中的 sanity 数字。
- 各 benchmark 在相同 evaluation scenario 下收到相同扰动。
