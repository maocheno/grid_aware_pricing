# 人为设定值登记表

本文件区分真实数据、派生数据和人为设定。除真实站点位置、ATC 交通流和 OSM 路网外，以下参数均属于 case-study 假设或训练超参数，论文中不应描述为 York 实测值。

## 1. 真实或派生数据

| 内容 | 性质 |
|---|---|
| York 路网节点和道路几何 | OSM 真实路网快照 |
| 2024-09-20 16:00--21:00 ATC 流量 | York 真实交通计数 |
| 8 个 charging hub 的坐标 | York Open Data 真实位置 |
| OD-to-hub route/free-flow time | 从 OSM 路网派生 |
| `potential_charging_requests` | 真实 car count 乘人为设定的 1.5% |

6 个 OD group 是为了形成小型网络而主观选取，并非官方 OD survey：

| OD | ATC 起终点 | 标签 |
|---|---:|---|
| OD01 | 2 -> 21 | West_to_East |
| OD02 | 34 -> 11 | Northwest_to_South |
| OD03 | 40 -> 11 | North_to_South |
| OD04 | 26 -> 50 | Northeast_to_Southwest |
| OD05 | 50 -> 40 | Southwest_to_North |
| OD06 | 21 -> 2 | East_to_West |

## 2. 充电站设施参数

站点位置是真实的，以下设施参数全部是人为设置：

| Hub | 枪数 | 单枪 kW | 等候位 | PV kW | 电池 kWh | 电池 kW | 电网 kW | 初始 SOC |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| H01 | 4 | 50 | 4 | 80 | 200 | 100 | 250 | 0.55 |
| H02 | 4 | 50 | 4 | 60 | 200 | 100 | 250 | 0.50 |
| H03 | 6 | 50 | 6 | 60 | 300 | 150 | 350 | 0.60 |
| H04 | 4 | 50 | 4 | 80 | 250 | 100 | 250 | 0.65 |
| H05 | 8 | 50 | 8 | 150 | 500 | 250 | 500 | 0.70 |
| H06 | 8 | 100 | 8 | 200 | 600 | 300 | 700 | 0.75 |
| H07 | 6 | 50 | 6 | 50 | 300 | 150 | 350 | 0.55 |
| H08 | 8 | 50 | 8 | 180 | 500 | 250 | 500 | 0.70 |

所有站的用户价格下限为 0.25 GBP/kWh，上限为 0.80 GBP/kWh，初始/固定 benchmark 价格为 0.45 GBP/kWh。

## 3. 交通模型假设

| 参数 | 当前值 |
|---|---:|
| BPR `alpha` | 0.15 |
| BPR `beta` | 4.0 |
| Trunk 默认速度 | 80 km/h |
| Trunk link | 50 km/h |
| Primary / primary link | 50 / 40 km/h |
| Secondary / secondary link | 45 / 35 km/h |
| Tertiary / tertiary link | 40 / 30 km/h |
| Unclassified | 30 km/h |
| Trunk / trunk link 容量 | 2000 / 1400 veh/h/direction |
| Primary / primary link 容量 | 1800 / 1200 veh/h/direction |
| Secondary / secondary link 容量 | 1500 / 1000 veh/h/direction |
| Tertiary / tertiary link 容量 | 1200 / 900 veh/h/direction |
| Unclassified 容量 | 850 veh/h/direction |

没有 ATC 的道路按 road-class hourly profile 外推流量。这是稀疏观测下的建模假设，不是真实逐边流量。

## 4. 需求和车辆能量

| 参数 | 当前值 |
|---|---:|
| 交通流转潜在充电请求比例 | 0.015，即 1.5% |
| Episode demand multiplier | 截断正态 |
| Multiplier 均值 / 标准差 | 1.00 / 0.08 |
| Multiplier 范围 | 0.85--1.15 |
| 单车充电量分布 | 截断正态 |
| 均值 / 标准差 | 25 / 7 kWh |
| 最小 / 最大充电量 | 8 / 50 kWh |
| 观测需求噪声标准差 | 期望需求的 2% |

1.5% 是为了让系统出现局部拥堵、但总体容量仍可通过价格协调重新分配的结果友好设定。

## 5. 用户选择和偏好推断

| 参数 | 当前值 |
|---|---:|
| Logit inverse cost sensitivity `lambda` | **0.55 GBP^-1** |
| Value of time | 18 GBP/h |
| Hidden true outside-option cost | 16.5 GBP |
| Estimator 初始 outside cost | 13.5 GBP |
| Estimator 范围 | 10--22 GBP |
| Estimator learning rate | 0.04 |
| Rolling loss window | 3 periods |
| 不可达 hub cost | 1000 GBP |
| Expected wait | 上一时段实际等待 |

### 关于 lambda

当前 `lambda=0.55 GBP^-1` 是人为校准值，不来自 York choice survey。因为 generalized cost 直接用 GBP 表示，lambda 带有 `GBP^-1` 单位。

英国 DfT TAG M2.1 Appendix D 将 `theta` 描述为层级 scaling parameter，并说明底层的 `theta` 恒为 1；同一节将 `lambda` 描述为由用户定义且必须为正的 spread/dispersion parameter。Appendix F 进一步建议用观测选择数据估计 scale。因此不能仅凭“底层参数等于 1”直接断定本式中的 lambda 必须为 1。

官方文件：
[DfT TAG Unit M2.1 Variable Demand Modelling](https://assets.publishing.service.gov.uk/media/69a034423e672177d0bc7710/tag-unit-m21-variable-demand-modelling.pdf)

如果采用 `lambda=1 GBP^-1`，必须重新运行选择、排队和 outside-cost calibration；不能只替换数字并沿用原 sanity check。

## 6. 排队模型

| 参数 | 当前值 |
|---|---:|
| 平均服务时间 | 0.5 h/vehicle |
| 最大可接受等待 | 0.25 h，即 15 min |
| 时间步长 | 1 h |
| Queue discipline | Dynamic aggregate fluid carry-over |
| 初始等待 / 排队能量 | 0 h / 0 kWh |
| 跨时段状态 | `T_i^wait(t)` 与 `E_i^que(t+1)` |
| 服务准入 | 式 (13)--(16) 的 `L_i(t)` 与 `rho_i(t)` |
| 有限等待位 | Base case 不强制执行 |

主场景不追踪逐车身份或到达顺序，但会以等效等待时间和排队能量结转 backlog。`queue_capacity_vehicles` 是人为设置的可选扩展参数，不进入当前论文 base equations，也不用于计算旧版 `overflow`。

## 7. PV、电价和电池时序

| 小时 | PV factor | 电网购电价 GBP/kWh | Battery continuation GBP/kWh |
|---:|---:|---:|---:|
| 16:00 | 0.55 | 0.16 | 0.25 |
| 17:00 | 0.35 | 0.22 | 0.33 |
| 18:00 | 0.16 | 0.30 | 0.35 |
| 19:00 | 0.04 | 0.34 | 0.32 |
| 20:00 | 0.00 | 0.27 | 0.24 |
| 21:00 | 0.00 | 0.20 | 0.12 |

其他能源参数：

| 参数 | 当前值 |
|---|---:|
| Battery charge/discharge efficiency | 0.95 / 0.95 |
| SOC 范围 | 0.10--0.95 |
| Battery degradation cost | 0.03 GBP/kWh throughput |
| PV O&M cost | 0.005 GBP/kWh |
| Operating cost | 1.50 GBP/served vehicle |
| Dispatch unmet priority penalty | 10 GBP/kWh |
| Grid-to-battery | 允许 |
| Battery export | 不允许 |
| 同时充放电 | 不允许 |

PV factor、电网价格和 continuation value 都是人为的晚高峰 profile。

## 8. Reward 和约束

| 参数 | 当前值 |
|---|---:|
| 8 个 hub profit weights | 全部为 1.0 |
| Wait-excess penalty | 120 GBP/h |
| Unmet-energy reward penalty | 6 GBP/kWh |
| Reward scale | 0.01 |

价格、PV balance、SOC、battery power 和 grid import limit 为 hard constraints；等待和 unmet energy 通过 penalty 处理并单独报告。

## 9. MAPPO 超参数

| 参数 | 当前值 |
|---|---:|
| Actor parameter sharing | False |
| Centralized critic | True |
| Actor hidden layers | [128, 128] |
| Critic hidden layers | [256, 256] |
| Activation | tanh |
| Actor / critic learning rate | 3e-4 / 1e-3 |
| Gamma / GAE lambda | 0.98 / 0.95 |
| PPO clip | 0.20 |
| Entropy coefficient | 0.010 -> 0.001 |
| Value loss coefficient | 0.50 |
| Max gradient norm | 0.50 |
| Horizon | 6 |
| Update epochs | 10 |
| Minibatch | 64 |
| Episodes per seed | 3000 |
| Seeds | 11, 29, 47 |
| Evaluation episodes per seed | 200 |

这些属于算法设置，应通过学习曲线和稳定性检查验证，不属于真实数据。
