# 数据与模型映射

## 1. 运行时输入

程序只需要读取 `data/scenario_config.yaml`，然后以该文件所在目录为基准解析另外六个路径。不要在代码中写死绝对路径。

| 文件 | 主要内容 | 在模型中的作用 | 读取频率 |
|---|---|---|---|
| `road_nodes.csv` | OSM node、经纬度 | 建立路网节点、绘制地图 | 初始化一次 |
| `road_edges.csv` | 有向边、道路等级、长度、限速、几何 | 自由流时间、BPR 时间、最短路 | 初始化一次 |
| `traffic_flow.csv` | 17 个 ATC 的逐小时分方向流量 | 构造每小时边流量 `x_e(t)` | 每个时段索引 |
| `charging_hubs.csv` | 8 个站的位置和设施参数 | 充电能力、排队、PV、储能、电网和价格边界 | 初始化一次 |
| `od_demand.csv` | 6 个 OD 的逐小时潜在需求 | `D_k(t)`、能量需求分布、候选站和自由流路径 | 每个时段索引 |
| `energy_profiles.csv` | 各站逐小时 PV、电价和初始 SOC | 能源调度和运营成本 | 每个时段索引 |
| `scenario_config.yaml` | 全部行为、物理和训练参数 | 单一配置入口 | 启动时一次 |

`model_input_manifest.csv` 只记录来源、范围和假设性质，不参与训练或 evaluation。

## 2. 路网数据

### `road_nodes.csv`

- `node_id`：与边表的 `u`、`v` 以及 OD、hub、counter 的 snapped node 对应。
- `longitude`, `latitude`：地图和几何检查使用，不直接进入 reward。

### `road_edges.csv`

- `u`, `v`：有向边起终点。
- `highway`：从 YAML 读取默认速度和每方向容量。
- `length_m`：计算自由流时间。
- `maxspeed_tag`：存在时优先于道路等级默认速度；要正确解析 `mph`。
- `lanes_tag`：可用于稀疏交通流外推；缺失时取 1。
- `geometry_wkt`：仅地图和 counter-to-edge snapping 使用，训练循环中不需要重复解析。

自由流时间：

```text
T0_e_min = length_m / (speed_kph * 1000 / 60)
```

BPR 时间：

```text
T_e(t) = T0_e * [1 + alpha * (x_e(t) / C_e)^beta]
```

其中 `alpha=0.15`、`beta=4.0`，容量 `C_e` 来自 YAML 的道路等级表。

### `traffic_flow.csv`

- 使用 `motor_vehicle_count`，不要再用 `total_count` 或 `car_count` 重复计数。
- `timestamp_local` 是小时索引。
- `nearest_road_node_id` 是 counter 与路网的连接点。
- `direction` 可转为方位角，用于从相邻有向边中选取方向最接近的边。

由于只有 17 个 counter，不能声称获得了每条道路的真实流量。推荐的可复现外推方法：

1. 将每个 counter 映射到 `nearest_road_node_id` 附近、方向最匹配的有向边。
2. 被观测边直接采用该方向的 `motor_vehicle_count`。
3. 未观测边采用同一 `road_class` 在该小时的流量中位数，并按车道数调整。
4. 将 `x_e/C_e` 限制在合理范围，例如 `[0, 1.20]`，避免稀疏外推产生异常旅行时间。
5. 初始化时生成并缓存 counter-edge mapping；每个 episode 不要重新做几何匹配。

若第一版程序只需先跑通，可以使用 `route_freeflow_time_min_json` 乘以按小时计算的 road-class BPR multiplier。正式主结果建议使用路网最短路版本。

## 3. Hub 数据

### `charging_hubs.csv`

- `nearest_road_node_id`：路网中的站点节点。
- `num_chargers`：充电枪数 `N_i`。
- `charger_power_kw`：单枪额定功率。
- `queue_capacity_vehicles`：预留的站外等待位上限，仅供有限队列扩展；新版论文 base equations 不强制使用该字段。
- `pv_capacity_kw`、`battery_capacity_kwh`、`battery_power_kw`、`grid_import_limit_kw`：能源约束。
- `min_price_gbp_per_kwh`、`max_price_gbp_per_kwh`：动作映射边界。
- `initial_price_gbp_per_kwh`：episode 第一个时段的 previous price。

位置是真实 York Open Data；设施和能源参数是 case-study 假设。论文表格中必须区分这两类来源。

每小时车辆服务能力：

```text
S_i = num_chargers_i * delta_t / average_service_time
```

当前设置 `delta_t=1 h`、平均服务时间 `0.5 h`，所以每个充电枪每小时对应 2 个 service slots。

主模型还维护两个跨时段状态：`T_i^wait(t-1)` 表示期初结转等待，`E_i^que(t)` 表示期初尚未准入服务的排队能量。两者在 episode reset 时均设为 0，随后按式 (10) 和式 (19) 逐时更新。

## 4. OD 需求

### `od_demand.csv`

- 一行代表一个 `(timestamp, OD)`。
- `source_car_count` 是真实 ATC 车流基数。
- `potential_charging_requests = source_car_count * 0.015` 已经计算完成，程序不要再次乘 1.5%。
- `potential_charging_requests` 是期望值，因此允许小数。
- `mean/std/min/max_requested_energy_kwh` 定义截断正态能量需求。
- `route_freeflow_time_min_json` 给出经过每个 hub 的自由流总时间。
- `detour_freeflow_time_min_json` 给出相对直接 OD 的绕行时间。
- `candidate_hub_ids` 定义可选集合。

训练 episode 推荐：

```text
m_episode ~ TruncatedNormal(1.0, 0.08, 0.85, 1.15)
N_k(t) ~ Poisson(potential_charging_requests * m_episode)
E_vehicle ~ TruncatedNormal(25, 7, 8, 50) kWh
```

确定性 evaluation 使用期望需求，不进行 Poisson 抽样，以便不同方法逐时公平比较。

## 5. 能源曲线

### `energy_profiles.csv`

- `pv_available_kwh` 已等于 `pv_capacity_kw * pv_availability_factor * 1 h`。
- `grid_price_gbp_per_kwh` 是 hub 的购电成本，不是用户零售价。
- `grid_import_limit_kwh` 是一个小时内最大进口量；由于步长为 1 小时，数值等于 hub 表中的 kW 限值。
- `battery_continuation_value_gbp_per_kwh` 用于判断当前放电还是保留到后续高价时段。
- `initial_battery_soc_fraction` 只在 episode reset 时读取；随后 SOC 由状态转移决定。

同一时段的 PV factor 和 grid price 对所有站一致，但站点容量不同，因此绝对可用能源不同。

## 6. 配置文件

`scenario_config.yaml` 是唯一参数入口。程序启动时至少检查：

- 6 个小时、8 个 hub、6 个 OD 与 CSV 一致；
- 所有价格边界一致；
- SOC、battery power、grid import 和 PV 约束均存在；
- `true_hidden_cost_gbp` 不进入 actor 或 critic observation；
- `initial_estimate_gbp` 才是策略可使用的 outside-option cost。
- `carry_over_between_periods=true`，且 `initial_residual_wait_hours`、`initial_queued_energy_kwh` 非负。
