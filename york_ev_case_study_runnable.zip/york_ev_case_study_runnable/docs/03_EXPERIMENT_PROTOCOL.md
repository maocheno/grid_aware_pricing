# 实验与输出协议

## 1. 先跑通，再训练

### Stage A: deterministic environment

- 固定价格 0.45 GBP/kWh。
- 使用 OD 表中的期望需求，不进行随机抽样。
- 使用真实 hidden outside cost 生成选择，但不做 estimator 更新。
- 输出逐时 hub arrivals、`L_i`、`rho_i`、`E_i^pend`、`E_i^adm`、`E_i^que(t+1)`、wait、energy dispatch、SOC 和 profit。
- 结果应与 `scripts/smoke_test.py` 的需求分配和等待压力一致。

### Stage B: lower-layer only

- 固定价格保持 0.45。
- estimator 从 13.5 GBP 开始。
- 检查 `C_hat_out` 是否稳定趋近 16.5，而不是只检查 loss 是否下降。
- 若振荡，先对梯度按总需求归一化，再调整 learning rate。

### Stage C: MAPPO smoke training

- 单 seed、100--300 episodes。
- 只确认 reward、loss、gradient 和 action 均为有限值。
- 检查价格不是全部贴住上下界。
- 检查 policy 能完成 deterministic evaluation。

### Stage D: full training

- seeds：11、29、47。
- 每个 seed 3000 episodes。
- 每 20 个 episode 更新一次 PPO。
- 每个 seed 保存 best validation checkpoint 和 final checkpoint。

## 2. Main benchmarks

| 方法 | 价格策略 | Critic/reward | Outside cost |
|---|---|---|---|
| Fixed Tariff | 全站 0.45 | 无学习 | 环境真值仅用于模拟选择 |
| Myopic Local Pricing | 每站逐时局部优化 | 本地即时利润 | 固定估计 13.5 |
| Independent PPO | 独立 actor 和本地 critic | 本地 reward | 固定估计 13.5 |
| MAPPO-No-Inference | 独立 actor、central critic | shared reward | 固定错误值 13.5 |
| Proposed Dual-Layer MAPPO | 独立 actor、central critic | shared reward | lower-layer 动态估计 |
| Centralized Welfare Oracle | 联合搜索 8 个价格 | 完整系统目标 | 已知真值 16.5 |

Oracle 是上界，不应描述为可部署方法。8 个站、每站 9 个价格档位的全组合不可直接穷举；推荐使用 coordinate search、cross-entropy method 或受约束连续优化，并报告求解容差。

## 3. 公平比较规则

- 所有方法使用相同交通、OD、PV、电价和初始 SOC。
- stochastic evaluation 预先生成 scenario seeds，各方法复用同一批 episode。
- 所有方法使用同一 energy dispatch，不得只给 proposed method 更智能的电池控制。
- 所有利润只对 served energy 计费。
- evaluation 冻结网络、normalizer 和 estimator learning rate。
- 主要指标报告 3 个训练 seed 的 mean +/- standard deviation。

## 4. 日志结构

### 每个 period、每个 hub

```text
seed, episode, timestamp, method, hub_id,
price, arrivals, outside_share,
historical_equivalent_vehicles, total_pending_vehicles, admission_ratio,
wait_min, wait_excess_min, queued_energy_start_kwh,
requested_energy_kwh, pending_energy_kwh, admitted_energy_kwh,
queued_energy_next_kwh, served_energy_kwh, unmet_energy_kwh,
admitted_vehicles, served_vehicles, outside_share,
pv_used_kwh, battery_charge_kwh, battery_discharge_kwh,
soc_fraction, grid_import_kwh, grid_limit_utilization,
revenue_gbp, energy_cost_gbp, operating_cost_gbp, profit_gbp,
route_time_mean_min, detour_mean_min, c_out_estimate_gbp
```

### 每个 episode

```text
seed, episode, method, return,
aggregate_profit_gbp, system_welfare,
served_requests, outside_requests,
mean_wait_min, p95_wait_min, max_wait_min,
wait_violation_rate, unmet_energy_kwh,
pv_utilization, peak_grid_import_kwh,
mean_detour_min, c_out_absolute_error
```

统一写成长表 CSV 或 Parquet。画图脚本只读取 evaluation 日志，不直接读取训练器内部变量。

## 5. 主文结果

1. Study-area map：路网、17 个 counter、6 个 OD、8 个 hub。
2. Learning convergence：return、outside-cost estimate、NLL、violation rate。
3. Dynamic prices and allocation：8 站价格与 hub-hour demand heatmap。
4. Queue/service：mean、p95、max wait，15 分钟违规、admission ratio、queued energy 和 unmet energy。
5. Energy dispatch：PV、battery、grid、SOC、购电成本和 peak import。
6. Benchmark table：profit、welfare、service、feasibility、detour、oracle gap。

道路交通流是外生输入。结果可以报告 access travel time、detour 和 congestion-aware hub allocation，但不能声称价格策略降低了背景道路拥堵。

## 6. Ablation 与 sensitivity

### Ablation

- No Traffic State：route time 固定为 free flow。
- No Energy State：actor 不观察 PV、SOC 和 grid limit，但环境仍执行约束。
- Known Preference：直接提供 16.5 GBP，用来量化推断层性能损失。

### Sensitivity

- demand multiplier：0.85、1.00、1.15；
- grid capacity multiplier：0.85、1.00、1.15；
- true outside cost：14.0、16.5、19.0 GBP；
- 可选 PV multiplier：0.7、1.0、1.3。

主结论应先在 base case 成立，再用 sensitivity 说明不是依赖单一乐观参数。

## 7. 结果发布前检查

- 不使用训练 episode 作为最终 evaluation。
- 不只报告 best seed。
- 不预填改善百分比。
- 所有表格明确单位和统计口径。
- 对 oracle 说明优化方式和容差。
- 对真实数据与主观设置分别注明来源。
- 保存 config、代码 commit、seed 和 checkpoint，确保结果可复现。
