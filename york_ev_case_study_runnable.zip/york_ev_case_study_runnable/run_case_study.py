#!/usr/bin/env python3
"""One-command entry point for the packaged deterministic York case study."""

from __future__ import annotations

import argparse
import csv
import sys
import unittest
from pathlib import Path


PACKAGE_DIR = Path(__file__).resolve().parent
SCRIPTS_DIR = PACKAGE_DIR / "scripts"
DATA_DIR = PACKAGE_DIR / "data"
sys.path.insert(0, str(SCRIPTS_DIR))

from baseline_plots import create_baseline_figures  # noqa: E402
from fixed_tariff_model import run_fixed_tariff  # noqa: E402
from smoke_test import load_config, read_csv, validate_inputs  # noqa: E402


def write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        raise ValueError(f"Cannot write an empty result table: {path}")
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def run_queue_tests() -> None:
    suite = unittest.defaultTestLoader.discover(
        str(SCRIPTS_DIR), pattern="test_*.py"
    )
    result = unittest.TextTestRunner(stream=sys.stdout, verbosity=1).run(suite)
    if not result.wasSuccessful():
        raise SystemExit("Queue-state tests failed")


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Run the deterministic York fixed-tariff case study."
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=PACKAGE_DIR / "results" / "fixed_tariff",
        help="Directory for CSV results and SVG figures.",
    )
    args = parser.parse_args()

    print("[1/4] Running queue-state unit tests", flush=True)
    run_queue_tests()

    print("[2/4] Loading and validating the seven model inputs")
    config = load_config(DATA_DIR / "scenario_config.yaml")
    runtime_files = [
        "road_nodes.csv",
        "road_edges.csv",
        "traffic_flow.csv",
        "charging_hubs.csv",
        "od_demand.csv",
        "energy_profiles.csv",
    ]
    tables = {name: read_csv(name) for name in runtime_files}
    validate_inputs(config, tables)

    print("[3/4] Running the six-period fixed-tariff baseline")
    run = run_fixed_tariff(config, tables)
    args.output_dir.mkdir(parents=True, exist_ok=True)
    system_path = args.output_dir / "system_hourly_results.csv"
    hub_path = args.output_dir / "hub_hourly_results.csv"
    write_csv(system_path, run.system_rows)
    write_csv(hub_path, run.hub_rows)

    print("[4/4] Creating baseline SVG figures")
    figures = create_baseline_figures(
        args.output_dir / "figures", run.system_rows, run.hub_rows
    )

    peak_wait = max(float(row["maximum_wait_minutes"]) for row in run.system_rows)
    peak_queue = max(
        float(row["total_queued_energy_next_kwh"]) for row in run.system_rows
    )
    min_margin = min(
        float(row["minimum_supply_margin_upper_bound_kwh"])
        for row in run.system_rows
    )
    print("\nCompleted successfully")
    print(f"  Maximum residual wait: {peak_wait:.3f} min")
    print(f"  Peak queued energy:    {peak_queue:.3f} kWh")
    print(f"  Minimum supply margin: {min_margin:.3f} kWh")
    print(f"  System results: {system_path}")
    print(f"  Hub results:    {hub_path}")
    print(f"  Figures:        {len(figures)} files in {args.output_dir / 'figures'}")


if __name__ == "__main__":
    main()
