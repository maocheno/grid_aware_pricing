# 发布包清单

## 1. 当前版本中已更新的内容

| 文件 | 更新内容 |
|---|---|
| `data/scenario_config.yaml` | 启用跨时段等待与排队能量结转，记录式 (10)、(13)、(14)、(19) |
| `scripts/queue_state.py` | 新版排队状态转移的独立实现 |
| `scripts/fixed_tariff_model.py` | 六小时固定价确定性基准与逐站结果 |
| `scripts/smoke_test.py` | 使用新版状态转移复现参考数字 |
| `scripts/test_queue_state.py` | 等待、车辆 backlog 和排队能量守恒测试 |
| `scripts/test_fixed_tariff_model.py` | 六小时基准回归测试 |
| `scripts/baseline_plots.py` | 零依赖 SVG 基准图 |
| `run_case_study.py` | 单命令运行入口 |
| `docs/` | 数据映射、实现顺序、实验协议与假设登记均已同步新版公式 |

## 2. 沿用且无需修改的模型输入

| 文件 | 内容 |
|---|---|
| `data/road_nodes.csv` | York OSM 路网节点 |
| `data/road_edges.csv` | York OSM 有向路段 |
| `data/traffic_flow.csv` | 2024-09-20 16:00--21:00 ATC 交通流 |
| `data/charging_hubs.csv` | 8 个站位置及人为设施参数 |
| `data/od_demand.csv` | 6 个 OD、6 个小时的潜在需求 |
| `data/energy_profiles.csv` | 8 站逐小时 PV、电价和初始 SOC |
| `data/model_input_manifest.csv` | 数据来源和假设审计信息，不进入模型状态 |

## 3. 运行后生成的结果

```text
results/fixed_tariff/
|-- system_hourly_results.csv
|-- hub_hourly_results.csv
`-- figures/
    |-- fig_01_demand_split.svg
    |-- fig_02_maximum_wait.svg
    |-- fig_03_queued_energy.svg
    `-- fig_04_hub_wait_heatmap.svg
```

这些结果是 Fixed Tariff 基准，不是 Proposed Dual-Layer MAPPO 的最终结果。
