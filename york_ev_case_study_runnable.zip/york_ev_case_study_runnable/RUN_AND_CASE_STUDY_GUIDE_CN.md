# 运行与 Case Study 任务说明

## 1. 这个文件包现在能运行什么

当前版本已经可以直接运行：

1. 七个模型输入的结构和节点引用检查；
2. 新版式 (10)、(13)--(16)、(19) 的跨时段队列状态转移；
3. 0.45 GBP/kWh 固定价格下的六小时确定性用户选择；
4. 系统级和逐站级结果 CSV；
5. 需求、等待和排队能量的 4 张基准图。

当前版本还不是完整论文算法。以下内容需要在此包上继续实现：BPR 动态最短路、带 SOC 的能源调度、下层 outside-cost 推断、MAPPO、全部 benchmark 和多 seed evaluation。

## 2. 最快运行方法

### 系统要求

- Python 3.9 或更高版本；
- Fixed Tariff 基准不需要安装第三方包。

### 命令

```bash
cd york_ev_case_study_runnable
python3 run_case_study.py
```

如果直接在未改名的源目录运行，则进入该目录后执行同一条 Python 命令即可。

指定其他结果目录：

```bash
python3 run_case_study.py --output-dir results/my_test
```

### 成功标志

终端应显示：

```text
Ran 7 tests ... OK
PASS: 12/12 structural checks passed
Maximum residual wait: 75.996 min
Peak queued energy:    649.458 kWh
Minimum supply margin: 152.400 kWh
```

输出文件：

- `system_hourly_results.csv`：每小时潜在需求、公共充电需求、outside demand、最大等待、排队能量和能源余量；
- `hub_hourly_results.csv`：48 个 hub-hour 的 `L_i`、`rho_i`、等待、pending/admitted/queued energy；
- `figures/*.svg`：可直接用浏览器、PowerPoint、Word 或 LaTeX 打开。

## 3. 单独检查某一部分

```bash
python3 -m unittest discover -s scripts -p 'test_*.py'
python3 scripts/smoke_test.py
```

修改参数时，优先修改 `data/scenario_config.yaml`。例如 logit sensitivity 位于：

```yaml
user_choice:
  inverse_cost_sensitivity_lambda_per_gbp: 0.55
```

将其改成 0.22 或 0.30 后重新运行，即可得到 sensitivity 基准结果。每次实验应使用不同的 `--output-dir`，避免覆盖。

## 4. 完整论文程序的实现任务

### Task A：交通状态与路径

- 将 17 个 ATC 映射到 OSM 有向边；
- 按 road class 外推未观测边流量；
- 用 BPR 计算逐时边旅行时间；
- 输出每个 `(OD, hub, hour)` 的实际 route time 和 detour。

验收：旅行时间不小于自由流时间，并随流量单调增加。

### Task B：能源调度

- 输入 `E_i^adm(t)`，而不是全部新请求能量；
- 实现 PV、grid、battery charge/discharge、SOC 和 `U_i(t)`；
- 严格满足式 (17)--(19) 及能源平衡；
- 收紧部分站点能源容量，使 Fixed Tariff 出现适度局部 `unmet energy`，但全系统仍可协调解决。

验收：每站每小时能量平衡误差小于 `1e-6`，SOC 和功率约束无违规。

### Task C：下层偏好推断

- 环境用隐藏真值 16.5 GBP 生成选择；
- estimator 从 13.5 GBP 开始；
- 只使用聚合 hub/outside counts 更新共享 `C_out`；
- 记录 estimate、NLL 和 absolute error。

验收：固定价格实验中估计值稳定向真值收敛。

### Task D：MAPPO

- 8 个独立 actor、一个 centralized critic；
- local observation 必须包含 `T_i^wait(t-1)` 和 `E_i^que(t)`；
- shared reward 同时考虑利润、等待超限和 unmet energy；
- evaluation 使用确定性 Beta mean；
- 保存 checkpoint、normalizer、seed 和配置。

验收：价格不全部贴上下界，reward 和 loss 有限，多 seed 结果可复现。

### Task E：Benchmark

至少运行以下六种方法：

1. Fixed Tariff；
2. Myopic Local Pricing；
3. Independent PPO；
4. MAPPO-No-Inference；
5. Proposed Dual-Layer MAPPO；
6. Centralized Welfare Oracle。

所有方法必须共享相同需求扰动、交通、能源调度和初始 SOC。

## 5. 主文建议展示的图

### Fig. 1 Study Area and Inputs

- York 路网；
- 17 个 ATC、6 个 OD、8 个 charging hub；
- hub 点的大小表示 service capacity，颜色表示 grid capacity。

目的：证明交通流、路网和站点位置来自真实区域数据。

### Fig. 2 Learning and Preference Inference

建议三个 panel：

- episode return，显示 3 seeds mean 和标准差阴影；
- `C_out` estimate 与 16.5 GBP 真值；
- NLL、waiting violation rate 或 queued-energy violation rate。

目的：证明下层推断收敛，上层策略训练稳定。

### Fig. 3 Dynamic Prices and Demand Allocation

建议两个 heatmap：

- hub x hour 的零售价格；
- hub x hour 的新到达车辆或 public demand share。

目的：展示策略如何把需求从 H01/H02/H07 转移到 H05/H06/H08。

### Fig. 4 Cross-Period Queue Dynamics

这是新版模型最重要的图，建议包含：

- 各方法 mean/p95/max wait；
- 系统总 `E_i^que(t)` 时序；
- 各 hub `rho_i(t)` 或等待时间 heatmap；
- 15 分钟阈值线和 violation frequency。

目的：明确展示上一时段未服务车辆没有消失，并说明 Proposed 如何更快消化 backlog。

### Fig. 5 Energy and Grid Operation

- PV、battery discharge、grid import 的系统堆叠图；
- 代表站 H01/H02 与 H05/H06 的 SOC 和 grid-limit utilization；
- admitted energy、served energy 和 unmet energy。

目的：展示需求转移如何利用空间能源灵活性。

### Fig. 6 Benchmark Performance

主结果建议用表格加一张 trade-off 图：

- x 轴：mean detour 或 access travel time；
- y 轴：system welfare 或 aggregate profit；
- 点大小/颜色：peak queued energy 或 wait-violation rate。

表格报告 profit、welfare、served requests、outside share、mean/p95/max wait、peak queued energy、unmet energy、PV utilization 和 oracle gap。

## 6. 附录图与 Sensitivity

建议放入附录：

- `lambda = 0.22, 0.30, 0.55` 的价格响应、outside share、最大等待和排队能量；
- demand multiplier = 0.85、1.00、1.15；
- grid capacity multiplier = 0.85、1.00、1.15；
- No Traffic State、No Energy State、Known Preference ablation；
- 三个训练 seed 的独立学习曲线；
- 各 hub 完整 SOC 与 queue trajectory。

## 7. 当前基准结果应如何使用

当前 Fixed Tariff 结果可以先用于：

- 验证新版跨时段队列代码；
- 确定最拥堵的 hub 和时段；
- 检查 15 分钟等待阈值是否能产生足够违规；
- 作为后续 benchmark 的固定参考。

当前最小能源供给余量仍为正，因此不能用这版基准声称 Proposed 降低了 unmet energy。正式训练前应统一重新校准局部 grid/battery 限制，再让所有 benchmark 使用完全相同的环境。
