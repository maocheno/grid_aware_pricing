# York EV Charging Case Study Model Package

这个文件夹是论文 case study 的独立输入包和程序实现指南。数据范围固定为
2024-09-20 16:00--21:00，共 6 个小时、6 个 OD group 和 8 个充电 hub。

## 当前可以做到什么

- 七个运行输入已经齐全，字段和节点引用经过检查。
- `run_case_study.py` 可以零第三方依赖运行固定价格、确定性用户选择和新版跨时段排队基准。
- 运行后自动导出系统级与逐站 CSV，并生成 4 张 SVG 基准图。
- 可以在此基础上继续实现交通时间、能源调度、偏好推断和 MAPPO 环境。
- `scripts/smoke_test.py` 会联合读取全部输入，运行固定电价下的选择和跨时段排队计算。
- `scripts/queue_state.py` 实现论文新版式 (10)、(13)--(16) 和 (19) 的状态转移。
- MAPPO 的最终收敛效果仍需训练、调参和多 seed evaluation，不能由输入检查替代。

## 文件夹结构

```text
york_model_package/
|-- README.md
|-- RUN_AND_CASE_STUDY_GUIDE_CN.md
|-- PACKAGE_MANIFEST.md
|-- run_case_study.py
|-- requirements-smoke.txt
|-- requirements.txt
|-- data/
|   |-- road_nodes.csv
|   |-- road_edges.csv
|   |-- traffic_flow.csv
|   |-- charging_hubs.csv
|   |-- od_demand.csv
|   |-- energy_profiles.csv
|   |-- scenario_config.yaml
|   `-- model_input_manifest.csv
|-- docs/
|   |-- 01_DATA_AND_MODEL_MAPPING.md
|   |-- 02_IMPLEMENTATION_GUIDE.md
|   |-- 03_EXPERIMENT_PROTOCOL.md
|   `-- 04_ASSUMPTIONS_REGISTER.md
`-- scripts/
    |-- baseline_plots.py
    |-- fixed_tariff_model.py
    |-- queue_state.py
    |-- smoke_test.py
    |-- test_fixed_tariff_model.py
    `-- test_queue_state.py
```

运行时只读取前七个数据文件。`model_input_manifest.csv` 用于数据来源审计，不应作为环境状态输入。

## 最小检查

最简单的运行方式不需要安装第三方依赖：

```bash
cd york_model_package
python3 run_case_study.py
```

结果写入 `results/fixed_tariff/`。也可以单独运行检查：

```bash
cd york_model_package
python -m unittest discover -s scripts -p 'test_*.py'
python scripts/smoke_test.py
```

正确输出应包括：

- `12/12 structural checks passed`；
- 总潜在充电请求约 `382.830`；
- 17:00 峰值约 `103.800`；
- 固定 0.45 GBP/kWh 下最大结转等待约 `75.996 min`；
- 峰值结转排队能量约 `649.458 kWh`；
- 最小准入能量供给余量约 `152.400 kWh`；
- 20:00 后结转等待和排队能量恢复为 0。

这些数字是新版排队状态转移的 sanity check，不是 proposed policy 的实验结果。正供给余量说明当前 base case 在服务准入后没有触发能源不足；正式 case study 若要展示 `unmet energy` 改善，需要再校准局部电网或储能约束。

完整运行步骤、后续编码任务、benchmark 和图表清单见 `RUN_AND_CASE_STUDY_GUIDE_CN.md`。

## 推荐阅读顺序

1. `docs/01_DATA_AND_MODEL_MAPPING.md`：每个文件如何进入论文方程。
2. `docs/02_IMPLEMENTATION_GUIDE.md`：程序模块、环境 step 顺序和 MAPPO 接口。
3. `docs/03_EXPERIMENT_PROTOCOL.md`：benchmark、训练、评估和结果输出。
4. `docs/04_ASSUMPTIONS_REGISTER.md`：全部人为参数、单位和当前数值。

建议先完成 deterministic fixed-tariff environment，再加入偏好推断，最后接入 MAPPO。这样每一层都能单独验证。
