#!/usr/bin/env python3
"""Deterministic fixed-tariff model used by the runnable case-study package."""

from __future__ import annotations

import json
import math
from collections import defaultdict
from dataclasses import dataclass
from typing import Any

from queue_state import QueueState, transition_queue


@dataclass(frozen=True)
class FixedTariffRun:
    system_rows: list[dict[str, Any]]
    hub_rows: list[dict[str, Any]]
    final_queue_states: dict[str, QueueState]


def stable_probabilities(
    costs: dict[str, float],
    outside_cost: float,
    sensitivity: float,
) -> dict[str, float]:
    """Return stable multinomial-logit probabilities for hubs and outside option."""
    utilities = {key: -sensitivity * value for key, value in costs.items()}
    utilities["OUT"] = -sensitivity * outside_cost
    shift = max(utilities.values())
    weights = {key: math.exp(value - shift) for key, value in utilities.items()}
    denominator = sum(weights.values())
    return {key: value / denominator for key, value in weights.items()}


def run_fixed_tariff(
    config: dict[str, Any],
    tables: dict[str, list[dict[str, str]]],
) -> FixedTariffRun:
    """Run the six-period deterministic baseline and return auditable long tables."""
    hubs = {row["hub_id"]: row for row in tables["charging_hubs.csv"]}
    demand_by_time: dict[str, list[dict[str, str]]] = defaultdict(list)
    for row in tables["od_demand.csv"]:
        demand_by_time[row["timestamp_local"]].append(row)
    energy = {
        (row["timestamp_local"], row["hub_id"]): row
        for row in tables["energy_profiles.csv"]
    }

    sensitivity = float(
        config["user_choice"]["inverse_cost_sensitivity_lambda_per_gbp"]
    )
    value_of_time = float(config["user_choice"]["value_of_time_gbp_per_hour"])
    outside_cost = float(
        config["user_choice"]["outside_option"]["true_hidden_cost_gbp"]
    )
    service_time = float(config["queue_model"]["average_service_time_hours"])
    max_wait = float(config["queue_model"]["maximum_wait_hours"])
    delta_t = float(config["scenario"]["time_step_hours"])
    price = float(config["pricing"]["initial_reference_price_gbp_per_kwh"])

    service_capacity = {
        hub_id: float(row["num_chargers"]) * delta_t / service_time
        for hub_id, row in hubs.items()
    }
    queue_states = {
        hub_id: QueueState(
            residual_wait_hours=float(
                config["queue_model"]["initial_residual_wait_hours"]
            ),
            queued_energy_kwh=float(
                config["queue_model"]["initial_queued_energy_kwh"]
            ),
        )
        for hub_id in hubs
    }

    system_rows: list[dict[str, Any]] = []
    hub_rows: list[dict[str, Any]] = []

    for timestamp in sorted(demand_by_time):
        hub_requests = {hub_id: 0.0 for hub_id in hubs}
        hub_requested_energy = {hub_id: 0.0 for hub_id in hubs}
        outside_requests = 0.0

        for row in demand_by_time[timestamp]:
            route_times = json.loads(row["route_freeflow_time_min_json"])
            request_energy = float(row["mean_requested_energy_kwh"])
            costs = {
                hub_id: price * request_energy
                + value_of_time
                * (
                    float(route_times[hub_id]) / 60.0
                    + queue_states[hub_id].residual_wait_hours
                )
                for hub_id in hubs
            }
            probabilities = stable_probabilities(costs, outside_cost, sensitivity)
            potential = float(row["potential_charging_requests"])
            outside_requests += potential * probabilities["OUT"]
            for hub_id in hubs:
                assigned_requests = potential * probabilities[hub_id]
                hub_requests[hub_id] += assigned_requests
                hub_requested_energy[hub_id] += assigned_requests * request_energy

        transitions = {
            hub_id: transition_queue(
                state=queue_states[hub_id],
                arrivals_vehicles=hub_requests[hub_id],
                requested_energy_kwh=hub_requested_energy[hub_id],
                service_capacity_vehicles=service_capacity[hub_id],
                period_hours=delta_t,
            )
            for hub_id in hubs
        }

        period_hub_rows: list[dict[str, Any]] = []
        for hub_id in sorted(hubs):
            hub = hubs[hub_id]
            profile = energy[(timestamp, hub_id)]
            transition = transitions[hub_id]
            supply_upper_bound = (
                float(profile["pv_available_kwh"])
                + float(profile["grid_import_limit_kwh"])
                + float(hub["battery_power_kw"]) * delta_t
            )
            admitted_energy = transition.admitted_energy_kwh
            temporary_unmet = max(admitted_energy - supply_upper_bound, 0.0)
            served_energy = admitted_energy - temporary_unmet
            energy_service_ratio = (
                served_energy / admitted_energy if admitted_energy > 0 else 0.0
            )
            admitted_vehicles = (
                transition.admission_ratio * transition.total_pending_vehicles
            )
            period_hub_rows.append(
                {
                    "timestamp_local": timestamp,
                    "hub_id": hub_id,
                    "retail_price_gbp_per_kwh": price,
                    "arrivals_vehicles": hub_requests[hub_id],
                    "previous_wait_minutes": (
                        queue_states[hub_id].residual_wait_hours * 60.0
                    ),
                    "historical_equivalent_vehicles": (
                        transition.historical_equivalent_vehicles
                    ),
                    "total_pending_vehicles": transition.total_pending_vehicles,
                    "service_capacity_vehicles": service_capacity[hub_id],
                    "admission_ratio": transition.admission_ratio,
                    "admitted_vehicles": admitted_vehicles,
                    "estimated_served_vehicles": (
                        energy_service_ratio * admitted_vehicles
                    ),
                    "requested_energy_kwh": transition.requested_energy_kwh,
                    "queued_energy_start_kwh": queue_states[hub_id].queued_energy_kwh,
                    "pending_energy_kwh": transition.pending_energy_kwh,
                    "admitted_energy_kwh": admitted_energy,
                    "queued_energy_next_kwh": (
                        transition.next_state.queued_energy_kwh
                    ),
                    "realized_wait_minutes": (
                        transition.next_state.residual_wait_hours * 60.0
                    ),
                    "wait_violation": int(
                        transition.next_state.residual_wait_hours > max_wait
                    ),
                    "supply_upper_bound_kwh": supply_upper_bound,
                    "supply_margin_upper_bound_kwh": (
                        supply_upper_bound - admitted_energy
                    ),
                    "temporary_unmet_energy_kwh": temporary_unmet,
                }
            )

        potential_total = sum(
            float(row["potential_charging_requests"])
            for row in demand_by_time[timestamp]
        )
        public_total = sum(hub_requests.values())
        system_rows.append(
            {
                "timestamp_local": timestamp,
                "potential_requests": potential_total,
                "expected_public_requests": public_total,
                "expected_outside_requests": outside_requests,
                "maximum_wait_minutes": max(
                    row["realized_wait_minutes"] for row in period_hub_rows
                ),
                "wait_violation_hubs": sum(
                    row["wait_violation"] for row in period_hub_rows
                ),
                "total_queued_energy_next_kwh": sum(
                    row["queued_energy_next_kwh"] for row in period_hub_rows
                ),
                "minimum_supply_margin_upper_bound_kwh": min(
                    row["supply_margin_upper_bound_kwh"] for row in period_hub_rows
                ),
                "temporary_unmet_energy_kwh": sum(
                    row["temporary_unmet_energy_kwh"] for row in period_hub_rows
                ),
            }
        )
        hub_rows.extend(period_hub_rows)
        queue_states = {
            hub_id: transition.next_state
            for hub_id, transition in transitions.items()
        }

    return FixedTariffRun(
        system_rows=system_rows,
        hub_rows=hub_rows,
        final_queue_states=queue_states,
    )
