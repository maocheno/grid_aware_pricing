#!/usr/bin/env python3
"""Dependency-free SVG figures for the deterministic baseline outputs."""

from __future__ import annotations

from html import escape
from pathlib import Path
from typing import Any


NAVY = "#16324F"
TEAL = "#1F6F78"
RED = "#B45245"
GOLD = "#D99B2B"
GRID = "#D7DEE5"
TEXT = "#15202B"
def _line_path(
    values: list[float],
    left: float,
    top: float,
    width: float,
    height: float,
    maximum: float,
) -> str:
    if not values:
        return ""
    step = width / max(len(values) - 1, 1)
    points = []
    for index, value in enumerate(values):
        x = left + index * step
        y = top + height - height * value / maximum
        points.append(f"{x:.1f},{y:.1f}")
    return " ".join(points)


def _write_line_chart(
    path: Path,
    title: str,
    labels: list[str],
    series: list[tuple[str, list[float], str]],
    y_label: str,
    threshold: float | None = None,
) -> None:
    width, height = 1000, 560
    left, top, chart_w, chart_h = 95, 90, 850, 360
    maximum = max([value for _, values, _ in series for value in values] + [1.0])
    if threshold is not None:
        maximum = max(maximum, threshold)
    maximum *= 1.12

    elements = [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">',
        f'<rect width="{width}" height="{height}" fill="white"/>',
        f'<text x="{left}" y="42" font-family="Arial" font-size="24" font-weight="700" fill="{NAVY}">{escape(title)}</text>',
        f'<text x="24" y="{top + chart_h / 2:.0f}" transform="rotate(-90 24 {top + chart_h / 2:.0f})" font-family="Arial" font-size="14" fill="{TEXT}">{escape(y_label)}</text>',
    ]
    for tick in range(6):
        y = top + chart_h - chart_h * tick / 5
        value = maximum * tick / 5
        elements.append(
            f'<line x1="{left}" y1="{y:.1f}" x2="{left + chart_w}" y2="{y:.1f}" stroke="{GRID}" stroke-width="1"/>'
        )
        elements.append(
            f'<text x="{left - 12}" y="{y + 5:.1f}" text-anchor="end" font-family="Arial" font-size="12" fill="{TEXT}">{value:.0f}</text>'
        )
    step = chart_w / max(len(labels) - 1, 1)
    for index, label in enumerate(labels):
        x = left + index * step
        elements.append(
            f'<text x="{x:.1f}" y="{top + chart_h + 30}" text-anchor="middle" font-family="Arial" font-size="12" fill="{TEXT}">{escape(label)}</text>'
        )
    if threshold is not None:
        y = top + chart_h - chart_h * threshold / maximum
        elements.extend(
            [
                f'<line x1="{left}" y1="{y:.1f}" x2="{left + chart_w}" y2="{y:.1f}" stroke="{RED}" stroke-width="2" stroke-dasharray="8 6"/>',
                f'<text x="{left + chart_w - 4}" y="{y - 8:.1f}" text-anchor="end" font-family="Arial" font-size="12" fill="{RED}">15-min limit</text>',
            ]
        )
    for name, values, color in series:
        points = _line_path(values, left, top, chart_w, chart_h, maximum)
        elements.append(
            f'<polyline points="{points}" fill="none" stroke="{color}" stroke-width="4" stroke-linejoin="round" stroke-linecap="round"/>'
        )
        for point in points.split():
            x, y = point.split(",")
            elements.append(
                f'<circle cx="{x}" cy="{y}" r="5" fill="white" stroke="{color}" stroke-width="3"/>'
            )
    legend_x = left
    for name, _, color in series:
        elements.append(
            f'<line x1="{legend_x}" y1="510" x2="{legend_x + 34}" y2="510" stroke="{color}" stroke-width="4"/>'
        )
        elements.append(
            f'<text x="{legend_x + 44}" y="515" font-family="Arial" font-size="14" fill="{TEXT}">{escape(name)}</text>'
        )
        legend_x += 220
    elements.append("</svg>")
    path.write_text("\n".join(elements), encoding="utf-8")


def _heat_color(value: float, maximum: float) -> str:
    ratio = min(max(value / maximum, 0.0), 1.0)
    start = (230, 242, 239)
    end = (180, 58, 47)
    rgb = tuple(round(a + (b - a) * ratio) for a, b in zip(start, end))
    return f"#{rgb[0]:02X}{rgb[1]:02X}{rgb[2]:02X}"


def _write_wait_heatmap(path: Path, hub_rows: list[dict[str, Any]]) -> None:
    hubs = sorted({str(row["hub_id"]) for row in hub_rows})
    times = sorted({str(row["timestamp_local"]) for row in hub_rows})
    lookup = {
        (str(row["hub_id"]), str(row["timestamp_local"])): float(
            row["realized_wait_minutes"]
        )
        for row in hub_rows
    }
    width, height = 1000, 620
    left, top, cell_w, cell_h = 120, 105, 130, 54
    maximum = max(lookup.values()) or 1.0
    elements = [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">',
        f'<rect width="{width}" height="{height}" fill="white"/>',
        f'<text x="{left}" y="42" font-family="Arial" font-size="24" font-weight="700" fill="{NAVY}">Fixed-tariff residual wait by hub (min)</text>',
    ]
    for col, timestamp in enumerate(times):
        label = timestamp[11:16]
        x = left + col * cell_w + cell_w / 2
        elements.append(
            f'<text x="{x:.1f}" y="82" text-anchor="middle" font-family="Arial" font-size="13" fill="{TEXT}">{label}</text>'
        )
    for row_index, hub_id in enumerate(hubs):
        y = top + row_index * cell_h
        elements.append(
            f'<text x="{left - 18}" y="{y + 34:.1f}" text-anchor="end" font-family="Arial" font-size="14" font-weight="700" fill="{TEXT}">{escape(hub_id)}</text>'
        )
        for col, timestamp in enumerate(times):
            value = lookup[(hub_id, timestamp)]
            x = left + col * cell_w
            fill = _heat_color(value, maximum)
            font_color = "white" if value / maximum > 0.55 else TEXT
            elements.extend(
                [
                    f'<rect x="{x:.1f}" y="{y:.1f}" width="{cell_w - 4}" height="{cell_h - 4}" rx="3" fill="{fill}"/>',
                    f'<text x="{x + (cell_w - 4) / 2:.1f}" y="{y + 33:.1f}" text-anchor="middle" font-family="Arial" font-size="14" font-weight="700" fill="{font_color}">{value:.1f}</text>',
                ]
            )
    elements.append(
        f'<text x="{left}" y="{top + len(hubs) * cell_h + 34}" font-family="Arial" font-size="12" fill="{TEXT}">Darker cells indicate longer cross-period residual waiting time.</text>'
    )
    elements.append("</svg>")
    path.write_text("\n".join(elements), encoding="utf-8")


def create_baseline_figures(
    output_dir: Path,
    system_rows: list[dict[str, Any]],
    hub_rows: list[dict[str, Any]],
) -> list[Path]:
    output_dir.mkdir(parents=True, exist_ok=True)
    labels = [str(row["timestamp_local"])[11:16] for row in system_rows]
    created = [
        output_dir / "fig_01_demand_split.svg",
        output_dir / "fig_02_maximum_wait.svg",
        output_dir / "fig_03_queued_energy.svg",
        output_dir / "fig_04_hub_wait_heatmap.svg",
    ]
    _write_line_chart(
        created[0],
        "Fixed-tariff public and outside demand",
        labels,
        [
            (
                "Public charging",
                [float(row["expected_public_requests"]) for row in system_rows],
                TEAL,
            ),
            (
                "Outside option",
                [float(row["expected_outside_requests"]) for row in system_rows],
                GOLD,
            ),
        ],
        "Expected requests",
    )
    _write_line_chart(
        created[1],
        "Fixed-tariff maximum residual wait",
        labels,
        [
            (
                "Maximum wait",
                [float(row["maximum_wait_minutes"]) for row in system_rows],
                RED,
            )
        ],
        "Minutes",
        threshold=15.0,
    )
    _write_line_chart(
        created[2],
        "Queued charging energy carried to the next period",
        labels,
        [
            (
                "Queued energy",
                [
                    float(row["total_queued_energy_next_kwh"])
                    for row in system_rows
                ],
                NAVY,
            )
        ],
        "kWh",
    )
    _write_wait_heatmap(created[3], hub_rows)
    return created
