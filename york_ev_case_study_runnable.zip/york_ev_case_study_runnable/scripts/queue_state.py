#!/usr/bin/env python3
"""Fluid queue state transition from paper Eqs. (10), (13)-(16), and (19)."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class QueueState:
    residual_wait_hours: float
    queued_energy_kwh: float


@dataclass(frozen=True)
class QueueTransition:
    historical_equivalent_vehicles: float
    total_pending_vehicles: float
    admission_ratio: float
    requested_energy_kwh: float
    pending_energy_kwh: float
    admitted_energy_kwh: float
    next_state: QueueState


def transition_queue(
    state: QueueState,
    arrivals_vehicles: float,
    requested_energy_kwh: float,
    service_capacity_vehicles: float,
    period_hours: float,
) -> QueueTransition:
    """Advance one hub's aggregate queue state by one decision period."""
    values = {
        "residual_wait_hours": state.residual_wait_hours,
        "queued_energy_kwh": state.queued_energy_kwh,
        "arrivals_vehicles": arrivals_vehicles,
        "requested_energy_kwh": requested_energy_kwh,
        "service_capacity_vehicles": service_capacity_vehicles,
        "period_hours": period_hours,
    }
    if any(value < 0 for value in values.values()):
        raise ValueError(f"Queue inputs must be nonnegative: {values}")
    if service_capacity_vehicles == 0 or period_hours == 0:
        raise ValueError("Service capacity and period duration must be positive")

    historical_vehicles = (
        service_capacity_vehicles / period_hours * state.residual_wait_hours
    )
    pending_vehicles = historical_vehicles + arrivals_vehicles
    admission_ratio = (
        min(1.0, service_capacity_vehicles / pending_vehicles)
        if pending_vehicles > 0
        else 0.0
    )

    pending_energy = state.queued_energy_kwh + requested_energy_kwh
    admitted_energy = admission_ratio * pending_energy
    next_queued_energy = pending_energy - admitted_energy
    next_wait = max(
        state.residual_wait_hours
        + period_hours * (arrivals_vehicles / service_capacity_vehicles - 1.0),
        0.0,
    )

    leftover_vehicles = max(
        pending_vehicles - service_capacity_vehicles,
        0.0,
    )
    equivalent_wait = period_hours / service_capacity_vehicles * leftover_vehicles
    if abs(next_wait - equivalent_wait) > 1e-10:
        raise AssertionError("Waiting-time and vehicle-backlog states are inconsistent")
    if abs(pending_energy - admitted_energy - next_queued_energy) > 1e-10:
        raise AssertionError("Queued-energy conservation failed")

    return QueueTransition(
        historical_equivalent_vehicles=historical_vehicles,
        total_pending_vehicles=pending_vehicles,
        admission_ratio=admission_ratio,
        requested_energy_kwh=requested_energy_kwh,
        pending_energy_kwh=pending_energy,
        admitted_energy_kwh=admitted_energy,
        next_state=QueueState(
            residual_wait_hours=next_wait,
            queued_energy_kwh=next_queued_energy,
        ),
    )

