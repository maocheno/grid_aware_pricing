#!/usr/bin/env python3
"""Regression tests for the packaged six-period deterministic baseline."""

import unittest

from fixed_tariff_model import run_fixed_tariff
from smoke_test import DATA_DIR, load_config, read_csv


class FixedTariffModelTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.config = load_config(DATA_DIR / "scenario_config.yaml")
        cls.tables = {
            name: read_csv(name)
            for name in [
                "charging_hubs.csv",
                "od_demand.csv",
                "energy_profiles.csv",
            ]
        }
        cls.case_result = run_fixed_tariff(cls.config, cls.tables)

    def test_reference_outputs(self) -> None:
        self.assertEqual(len(self.case_result.system_rows), 6)
        self.assertEqual(len(self.case_result.hub_rows), 48)
        self.assertAlmostEqual(
            max(
                row["maximum_wait_minutes"]
                for row in self.case_result.system_rows
            ),
            75.996,
            places=2,
        )
        self.assertAlmostEqual(
            max(
                row["total_queued_energy_next_kwh"]
                for row in self.case_result.system_rows
            ),
            649.458,
            places=2,
        )

    def test_energy_queue_conservation(self) -> None:
        for row in self.case_result.hub_rows:
            self.assertAlmostEqual(
                row["pending_energy_kwh"],
                row["admitted_energy_kwh"] + row["queued_energy_next_kwh"],
                places=8,
            )

    def test_end_state_is_clear(self) -> None:
        for state in self.case_result.final_queue_states.values():
            self.assertAlmostEqual(state.residual_wait_hours, 0.0)
            self.assertAlmostEqual(state.queued_energy_kwh, 0.0)


if __name__ == "__main__":
    unittest.main()
