#!/usr/bin/env python3
"""Validate packaged inputs and run a deterministic fixed-tariff sanity check."""

from __future__ import annotations

import csv
import json
import re
from pathlib import Path

from fixed_tariff_model import run_fixed_tariff

try:
    import yaml
except ImportError:
    yaml = None


PACKAGE_DIR = Path(__file__).resolve().parents[1]
DATA_DIR = PACKAGE_DIR / "data"


def read_csv(name: str) -> list[dict[str, str]]:
    with (DATA_DIR / name).open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def load_config(path: Path) -> dict:
    """Use PyYAML when present, with a strict scalar fallback for this smoke test."""
    text = path.read_text(encoding="utf-8")
    if yaml is not None:
        return yaml.safe_load(text)

    def scalar(key: str) -> str:
        matches = re.findall(rf"^\s*{re.escape(key)}:\s*(.+?)\s*$", text, re.MULTILINE)
        if len(matches) != 1:
            raise ValueError(f"Expected exactly one YAML scalar named {key!r}")
        return matches[0].strip('"\'')

    def number(key: str) -> int | float:
        value = scalar(key)
        parsed = float(value)
        return int(parsed) if parsed.is_integer() and "." not in value else parsed

    return {
        "scenario": {
            "number_of_hubs": number("number_of_hubs"),
            "number_of_od_groups": number("number_of_od_groups"),
            "time_step_hours": number("time_step_hours"),
        },
        "demand_generation": {
            "mean_requested_energy_kwh": number("mean_requested_energy_kwh"),
        },
        "user_choice": {
            "inverse_cost_sensitivity_lambda_per_gbp": number(
                "inverse_cost_sensitivity_lambda_per_gbp"
            ),
            "value_of_time_gbp_per_hour": number("value_of_time_gbp_per_hour"),
            "outside_option": {"true_hidden_cost_gbp": number("true_hidden_cost_gbp")},
        },
        "queue_model": {
            "average_service_time_hours": number("average_service_time_hours"),
            "maximum_wait_hours": number("maximum_wait_hours"),
            "initial_residual_wait_hours": number("initial_residual_wait_hours"),
            "initial_queued_energy_kwh": number("initial_queued_energy_kwh"),
        },
        "pricing": {
            "initial_reference_price_gbp_per_kwh": number(
                "initial_reference_price_gbp_per_kwh"
            ),
        },
    }


def check(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def validate_inputs(config: dict, tables: dict[str, list[dict[str, str]]]) -> None:
    nodes = tables["road_nodes.csv"]
    edges = tables["road_edges.csv"]
    traffic = tables["traffic_flow.csv"]
    hubs = tables["charging_hubs.csv"]
    demand = tables["od_demand.csv"]
    energy = tables["energy_profiles.csv"]

    node_ids = {row["node_id"] for row in nodes}
    hub_ids = sorted(row["hub_id"] for row in hubs)
    timestamps = sorted({row["timestamp_local"] for row in demand})

    checks = [
        (len(demand) == 36, "od_demand.csv must have 36 rows"),
        (len({row["od_id"] for row in demand}) == 6, "there must be 6 OD groups"),
        (len(timestamps) == 6, "there must be 6 hourly demand periods"),
        (len(energy) == 48, "energy_profiles.csv must have 48 rows"),
        (len(hub_ids) == 8, "there must be 8 hubs"),
        ({row["hub_id"] for row in energy} == set(hub_ids), "energy hub IDs mismatch"),
        (all(row["u"] in node_ids and row["v"] in node_ids for row in edges), "edge node missing"),
        (all(row["nearest_road_node_id"] in node_ids for row in hubs), "hub node missing"),
        (all(row["nearest_road_node_id"] in node_ids for row in traffic), "counter node missing"),
        (
            all(row["origin_node_id"] in node_ids and row["destination_node_id"] in node_ids for row in demand),
            "OD node missing",
        ),
        (
            all(sorted(json.loads(row["route_freeflow_time_min_json"])) == hub_ids for row in demand),
            "route-time hub keys mismatch",
        ),
        (
            config["scenario"]["number_of_hubs"] == 8
            and config["scenario"]["number_of_od_groups"] == 6,
            "YAML dimensions mismatch",
        ),
    ]
    for condition, message in checks:
        check(condition, message)
    print(f"PASS: {len(checks)}/{len(checks)} structural checks passed")


def fixed_tariff_sanity(config: dict, tables: dict[str, list[dict[str, str]]]) -> None:
    run = run_fixed_tariff(config, tables)

    print("\nFixed-tariff deterministic sanity check")
    print(
        "timestamp           potential  public  outside  max_wait  violations  "
        "queued_kwh  min_supply_margin"
    )
    for row in run.system_rows:
        print(
            f"{row['timestamp_local']}  {row['potential_requests']:9.3f}  "
            f"{row['expected_public_requests']:6.3f}  "
            f"{row['expected_outside_requests']:7.3f}  "
            f"{row['maximum_wait_minutes']:8.3f}  "
            f"{row['wait_violation_hubs']:10d}  "
            f"{row['total_queued_energy_next_kwh']:10.3f}  "
            f"{row['minimum_supply_margin_upper_bound_kwh']:17.3f}"
        )

    total_potential = sum(row["potential_requests"] for row in run.system_rows)
    peak_hourly = max(row["potential_requests"] for row in run.system_rows)
    maximum_wait = max(row["maximum_wait_minutes"] for row in run.system_rows)
    minimum_supply_margin = min(
        row["minimum_supply_margin_upper_bound_kwh"] for row in run.system_rows
    )
    maximum_queued_energy = max(
        row["total_queued_energy_next_kwh"] for row in run.system_rows
    )
    maximum_temporary_unmet = max(
        row["temporary_unmet_energy_kwh"] for row in run.system_rows
    )

    check(abs(total_potential - 382.830) < 0.002, "unexpected total demand")
    check(abs(peak_hourly - 103.800) < 0.002, "unexpected hourly peak")
    check(abs(maximum_wait - 75.996) < 0.01, "unexpected maximum wait")
    check(abs(minimum_supply_margin - 152.400) < 0.02, "unexpected supply margin")
    check(abs(maximum_queued_energy - 649.458) < 0.02, "unexpected queued energy")
    check(maximum_temporary_unmet < 1e-9, "unexpected temporary energy shortfall")
    check(
        all(
            state.residual_wait_hours < 1e-10
            for state in run.final_queue_states.values()
        ),
        "queue delay must clear by the end of the six-hour scenario",
    )
    check(
        all(
            state.queued_energy_kwh < 1e-8
            for state in run.final_queue_states.values()
        ),
        "queued energy must clear by the end of the six-hour scenario",
    )
    print("\nPASS: deterministic reference values reproduced")


def main() -> None:
    config = load_config(DATA_DIR / "scenario_config.yaml")

    runtime_files = [
        "road_nodes.csv",
        "road_edges.csv",
        "traffic_flow.csv",
        "charging_hubs.csv",
        "od_demand.csv",
        "energy_profiles.csv",
    ]
    tables = {name: read_csv(name) for name in runtime_files}
    validate_inputs(config, tables)
    fixed_tariff_sanity(config, tables)


if __name__ == "__main__":
    main()
