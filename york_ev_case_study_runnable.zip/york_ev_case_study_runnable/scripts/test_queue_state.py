#!/usr/bin/env python3
"""Unit tests for the revised cross-period fluid queue transition."""

import unittest

from queue_state import QueueState, transition_queue


class QueueStateTest(unittest.TestCase):
    def test_overload_is_carried_and_cleared_next_period(self) -> None:
        first = transition_queue(
            state=QueueState(0.0, 0.0),
            arrivals_vehicles=16.0,
            requested_energy_kwh=400.0,
            service_capacity_vehicles=8.0,
            period_hours=1.0,
        )
        self.assertAlmostEqual(first.next_state.residual_wait_hours, 1.0)
        self.assertAlmostEqual(first.admission_ratio, 0.5)
        self.assertAlmostEqual(first.next_state.queued_energy_kwh, 200.0)

        second = transition_queue(
            state=first.next_state,
            arrivals_vehicles=0.0,
            requested_energy_kwh=0.0,
            service_capacity_vehicles=8.0,
            period_hours=1.0,
        )
        self.assertAlmostEqual(second.historical_equivalent_vehicles, 8.0)
        self.assertAlmostEqual(second.admitted_energy_kwh, 200.0)
        self.assertAlmostEqual(second.next_state.residual_wait_hours, 0.0)
        self.assertAlmostEqual(second.next_state.queued_energy_kwh, 0.0)

    def test_partial_recovery_preserves_residual_wait(self) -> None:
        result = transition_queue(
            state=QueueState(0.75, 150.0),
            arrivals_vehicles=6.0,
            requested_energy_kwh=120.0,
            service_capacity_vehicles=8.0,
            period_hours=1.0,
        )
        self.assertAlmostEqual(result.historical_equivalent_vehicles, 6.0)
        self.assertAlmostEqual(result.next_state.residual_wait_hours, 0.5)
        self.assertAlmostEqual(result.total_pending_vehicles, 12.0)
        self.assertAlmostEqual(result.admission_ratio, 2.0 / 3.0)
        self.assertAlmostEqual(result.next_state.queued_energy_kwh, 90.0)

    def test_empty_queue_stays_empty(self) -> None:
        result = transition_queue(
            state=QueueState(0.0, 0.0),
            arrivals_vehicles=0.0,
            requested_energy_kwh=0.0,
            service_capacity_vehicles=8.0,
            period_hours=1.0,
        )
        self.assertEqual(result.admission_ratio, 0.0)
        self.assertEqual(result.next_state, QueueState(0.0, 0.0))

    def test_invalid_inputs_are_rejected(self) -> None:
        with self.assertRaises(ValueError):
            transition_queue(
                state=QueueState(-0.1, 0.0),
                arrivals_vehicles=1.0,
                requested_energy_kwh=25.0,
                service_capacity_vehicles=8.0,
                period_hours=1.0,
            )


if __name__ == "__main__":
    unittest.main()
